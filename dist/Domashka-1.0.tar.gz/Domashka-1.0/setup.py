from setuptools import setup, find_packages

setup(
    name='Domashka',
    version='1.0',
    packages=find_packages(),
    url='12',
    license='123',
    author='dmitriy',
    author_email='dmitry.zorkin1994@yandex.ru',
    description='proga',
)
