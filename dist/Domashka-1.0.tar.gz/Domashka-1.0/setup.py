from setuptools import setup, find_packages
from os.path import join, dirname

setup(
    name='Domashka',
    version='1.0',
    packages=find_packages(),
    url='12',
    license='123',
    author='dmitr_japaohm',
    author_email='dnitry.zorkin1994@yandex.ru',
    description='proga',
)
